from fastapi import APIRouter
from app.api.routes import router as busca_router

router = APIRouter()
router.include_router(busca_router, prefix="", tags=["busca"])
