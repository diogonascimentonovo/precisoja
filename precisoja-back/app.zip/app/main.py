from fastapi import *
from app.api.routes import router as api_router

app = FastAPI()

# inclui todas as rotas definidas em app/api/routes.py
app.include_router(api_router)
