mock_profissionais = [
    {
        "id": 1,
        "nome": "Carlos Refrigeração",
        "categoria": "Técnico em Refrigeração",
        "especialidade": "Geladeiras e Freezers",
        "avaliacao": 4.8
    },
    {
        "id": 2,
        "nome": "João Elétrico",
        "categoria": "Eletricista",
        "especialidade": "Fiação residencial",
        "avaliacao": 4.5
    },
    {
        "id": 3,
        "nome": "Maria Multisserviços",
        "categoria": "Técnico em Refrigeração",
        "especialidade": "Instalação de ar-condicionado e manutenção geral",
        "avaliacao": 4.9
    },
    {
        "id": 4,
        "nome": "André Encanador",
        "categoria": "Encanador",
        "especialidade": "Conserto de vazamentos e desentupimento",
        "avaliacao": 4.4
    }
]
